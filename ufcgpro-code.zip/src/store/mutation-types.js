export const UPDATE_FOO = 'UPDATE_FOO';
